﻿
using System;
using System.Collections.Generic;

public class Program
{
    public static void Main()
    {
        var orders = new List<IOrder>
        {
            new DomesticOrder { OrderDateTime = new DateTime(2022, 6, 1), Customer = new Customer { Id = 1, Name = "omar" } },
            new DomesticOrder { OrderDateTime = new DateTime(2023, 4, 15), Customer = new Customer { Id = 2, Name = "ahmad" } },
            new OverSeaOrder  { OrderDateTime = new DateTime(2022, 9, 20), Customer = new Customer { Id = 3, Name = "isaa" } },
            new OverSeaOrder  { OrderDateTime=  new DateTime(2022, 8, 20), Customer=  new Customer { Id = 9,Name ="mohammed"}},
            new DomesticOrder { OrderDateTime = new DateTime(2023, 2, 10), Customer = new Customer { Id = 4, Name = "amer" } }
        };

        var customersWithRecentOrders = GetCustomersWithAtLeastOneOrders(orders);

        foreach (var customer in customersWithRecentOrders)
        {
            Console.WriteLine($"Customer ID: {customer.Id}, Name: {customer.Name}");
        }
    }

    public static List<Customer> GetCustomersWithAtLeastOneOrders(List<IOrder> orders)
    {
        //I can loop through foreach with condition function but linq is the best *_* 

        var oneYearAgo = DateTime.Now.AddYears(-1);
        var customersWithRecentOrders = orders
            .Where(order => order.OrderDateTime >= oneYearAgo)
            .Select(order => order.Customer)
            .Distinct()
            .ToList();

        return customersWithRecentOrders;
    }
}

public interface IOrder
{
    IList<OrderItem> OrderItems { get; set; }
    Customer Customer { get; set; }
    DateTime OrderDateTime { get; set; }
}

public class OrderItem
{
    public string? ItemName { get; set; }
    public decimal ItemPrice { get; set; }
    public Guid CategoryId { get; set; }
}

public class Customer
{
    public int Id { get; set; }
    public string Name { get; set; }

}

public class DomesticOrder : IOrder
{
    public IList<OrderItem> OrderItems { get; set; }
    public Customer Customer { get; set; }
    public DateTime OrderDateTime { get; set; }

}

public class OverSeaOrder : IOrder
{
    public IList<OrderItem> OrderItems { get; set; }
    public Customer Customer { get; set; }
    public DateTime OrderDateTime { get; set; }

}
