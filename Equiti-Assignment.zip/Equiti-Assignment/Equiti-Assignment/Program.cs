﻿
namespace CurrencyCleanupApp
{
    public class Task2
    {
        private readonly string _jsonFeed1;
        private readonly string _jsonFeed2;

        public Task2(string jsonFeed1, string jsonFeed2)
        {
            _jsonFeed1 = jsonFeed1;
            _jsonFeed2 = jsonFeed2;
        }

        public Dictionary<string, decimal> GetLowestCurrencyRates(DateTime day)
        {
            JsonFeed2 RatesproviderB = new JsonFeed2();

            var jsonDict = JsonConvert.DeserializeObject<Dictionary<string, List<CurrencyRate>>>(_jsonFeed2);
            RatesproviderB.Rates = jsonDict;
            List<JsonFeed1> rates = JsonConvert.DeserializeObject<List<JsonFeed1>>(_jsonFeed1);
            rates.AddRange(
                RatesproviderB.Rates.SelectMany(item => item.Value, (item, item2) => new JsonFeed1
                {
                    CurrencyPair = item.Key,
                    Date = item2.Date,
                    Rate = item2.Rate
                })
            );
            var lowestRates = rates
                .Where(r => r.Date == day.ToString("yyyy-MM-dd"))
                .GroupBy(r => r.CurrencyPair)
                .ToDictionary(g => g.Key, g => g.Min(r => r.Rate));

            return lowestRates;
        }

        public class JsonFeed1
        {
            public string Date { get; set; }
            public string CurrencyPair { get; set; }
            public decimal Rate { get; set; }
        }

        public class JsonFeed2
        {
            public Dictionary<string, List<CurrencyRate>> Rates { get; set; }
        }

        public class CurrencyRate
        {
            public string Date { get; set; }
            public decimal Rate { get; set; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string jsonFeed1 = @"[
                {""date"": ""2020-10-01"", ""currencyPair"": ""JODUSD"", ""rate"": 1.41 },
                {""date"": ""2020-10-01"", ""currencyPair"": ""GBPUSD"", ""rate"": 1.33 },
                {""date"": ""2020-10-01"", ""currencyPair"": ""EURUSD"", ""rate"": 1.22 },
                {""date"": ""2020-10-02"", ""currencyPair"": ""JODUSD"", ""rate"": 1.42 },
                {""date"": ""2020-10-02"", ""currencyPair"": ""GBPUSD"", ""rate"": 1.32 }
            ]";

            string jsonFeed2 = @"{
                ""GBPUSD"": [{""date"": ""2020-10-01"", ""rate"": 1.32}, {""date"": ""2020-10-02"", ""rate"": 1.325}],
                ""JODUSD"": [{""date"": ""2020-10-01"", ""rate"": 1.41}, {""date"": ""2020-10-02"", ""rate"": 1.41}],
                ""test"": [{""date"": ""2020-10-01"", ""rate"": 1.30}, {""date"": ""2020-10-01"", ""rate"": 1.40}],
                ""AEDUSD"": [{""date"": ""2020-10-01"", ""rate"": 0.27}, {""date"": ""2020-10-02"", ""rate"": 0.27}]
            }";

            Task2 cleanupService = new Task2(jsonFeed1, jsonFeed2);

            DateTime specifiedDay;
            Console.WriteLine("Enter a date (yyyy-MM-dd):");
            string userInput = Console.ReadLine();
            if (DateTime.TryParse(userInput, out specifiedDay))
            {
                Dictionary<string, decimal> lowestRates = cleanupService.GetLowestCurrencyRates(specifiedDay);

                Console.WriteLine("Lowest Currency Rates for {0}:", specifiedDay.ToString("yyyy-MM-dd"));
                foreach (var pair in lowestRates)
                {
                    Console.WriteLine("Currency Pair: {0}, Rate: {1}", pair.Key, pair.Value);
                }
            }
            else
            {
                Console.WriteLine("Invalid date");
            }

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}
